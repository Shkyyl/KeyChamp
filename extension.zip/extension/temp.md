# Joining to battle after moving to case battle tab
function joinBattle(){
  const divs = document.querySelectorAll('div.flex-col.items-center.relative.opacity-100.z-10');
  divs.forEach(div => {
    const lastSpan = div.querySelectorAll('span')[20];
    lastSpan.forEach(span => {
      const clickListeners = getEventListeners(span).click;
      clickListeners.forEach(listener => {
        document.location.reload();
      })
    })
  })
}
function rel(){
  console.log('costam nie');
}
const targetUrlPattern = '*::/key-drop.com/pl/case-battle/[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]';
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.query({url:targetUrlPattern, currentWindow: true}, (tabs) => {
    if(tabs.length > 0){
      var tabId = tabs[0].id;
      chrome.scripting.executeScript({
        target: {tabId: tabId},
        func: rel,
      });
    } else {
      console.error("No active tab found");
    }
  })
});
# don't work

# Code implemetion after joinin to case battle tab
        while (true) {
          const offset = (Math.random() + 1.2);
          await new Promise(r => setTimeout(r, (100 * offset)));
          try {
            const joinBtn = document.querySelector('button.h-12.button-green-dimmed');
            if (joinBtn) {
              joinBtn.click();
              break;
            }
          } catch {null;}
        }
# useless becasue don't work